import { ArrowUpRight } from "lucide-react";
import { Translation } from "../types";

interface PositioningProps {
  t: Translation;
}

export default function Positioning({ t }: PositioningProps) {
  return (
    <section className="bg-[#F1EAD9] px-4 py-20 text-[#142841] sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="section-eyebrow section-eyebrow--light mb-6">
          {t.positioning_label}
        </div>

        <div className="grid grid-cols-[0.92fr_1.08fr] items-center gap-3 sm:grid-cols-2 sm:items-stretch md:gap-5">
          <div className="relative flex min-h-[250px] w-full flex-col items-center justify-center self-center rounded-2xl border border-[#DDD5C6] bg-white p-4 text-center shadow-[0_16px_50px_rgba(18,24,36,0.08)] sm:min-h-[280px] sm:items-stretch sm:justify-between sm:p-10 sm:text-left">
            <h2 className="font-display max-w-xl text-[1.35rem] uppercase leading-[0.95] tracking-wide text-[#142841] sm:text-5xl lg:text-6xl">
              {t.positioning_title}
            </h2>
            <ArrowUpRight className="absolute bottom-4 left-4 h-6 w-6 text-brand-blue sm:static sm:mt-8 sm:h-8 sm:w-8" aria-hidden="true" />
          </div>

          <div className="relative grid min-h-[320px] grid-rows-2 overflow-hidden rounded-2xl border border-brand-border bg-[#1B334F] p-4 text-center text-[#F1EAD9] sm:min-h-[280px] sm:p-10">
            <div className="absolute -right-16 -top-16 h-52 w-52 rounded-full bg-cyan-palette/10 blur-3xl" />
            <div className="relative flex items-center justify-center">
              <p className="max-w-xl text-xs leading-relaxed text-[#F1EAD9]/72 sm:text-lg">
                {t.positioning_body}
              </p>
            </div>
            <div className="relative flex items-center justify-center">
              <p className="max-w-xl border-l-2 border-cyan-palette pl-3 text-[11px] font-semibold leading-relaxed text-cyan-300 sm:pl-4 sm:text-base">
                {t.positioning_highlight}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
