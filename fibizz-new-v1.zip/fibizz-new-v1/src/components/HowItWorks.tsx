import React from "react";
import { Translation } from "../types";

interface HowItWorksProps {
  t: Translation;
}

export default function HowItWorks({ t }: HowItWorksProps) {
  const steps = t.como_steps;
  const [activeIndex, setActiveIndex] = React.useState(0);
  const activeStep = steps[activeIndex];

  return (
    <section id="como-funciona" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#F1EAD9] text-[#142841] scroll-mt-16">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="section-eyebrow section-eyebrow--light mb-4">{t.section_labels.process}</div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#142841]">
            {t.como_title}
          </h2>
        </div>

        {/* Interactive process */}
        <div className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="space-y-2" role="tablist" aria-label={t.como_title}>
            {steps.map((step, idx) => {
              const isActive = idx === activeIndex;
              return (
                <button
                  key={step.number}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  aria-controls="process-panel"
                  onClick={() => setActiveIndex(idx)}
                  className={`w-full rounded-xl border px-4 py-4 text-left transition-colors sm:px-5 ${
                    isActive
                      ? "border-cyan-palette/60 bg-brand-blue text-white"
                      : "border-[#DDD5C6] bg-white/60 text-[#142841]/75 hover:border-brand-blue/45 hover:bg-white"
                  }`}
                >
                  <span className="flex items-center justify-between gap-4">
                    <span className="flex items-center gap-4">
                      <span className={`font-mono text-xs font-bold ${isActive ? "text-cyan-200" : "text-cyan-palette"}`}>
                        {String(step.number).padStart(2, "0")}
                      </span>
                      <span className="text-sm font-semibold sm:text-base">{step.title}</span>
                    </span>
                    <span aria-hidden="true" className="text-lg">{isActive ? "−" : "+"}</span>
                  </span>
                </button>
              );
            })}
          </div>

          <div
            id="process-panel"
            role="tabpanel"
            className="relative flex min-h-[310px] flex-col justify-between overflow-hidden rounded-2xl border border-brand-blue/30 bg-brand-card p-7 shadow-2xl sm:p-10"
          >
            <div className="absolute -right-14 -top-20 font-display text-[13rem] leading-none text-brand-blue/[0.07]" aria-hidden="true">
              {String(activeStep.number).padStart(2, "0")}
            </div>
            <div className="relative">
              <span className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-cyan-palette">
                {String(activeStep.number).padStart(2, "0")} / {String(steps.length).padStart(2, "0")}
              </span>
              <h3 className="font-display mt-7 max-w-lg text-4xl uppercase leading-[0.95] tracking-wide text-white sm:text-5xl">
                {activeStep.title}
              </h3>
            </div>
            <p className="relative mt-10 max-w-xl border-l-2 border-cyan-palette pl-4 text-sm leading-relaxed text-[#F1EAD9]/68 sm:text-base">
              {activeStep.desc}
            </p>
          </div>
        </div>

        {/* Process Mockups / Side-by-Side browser windows */}
        <div className="mx-auto mt-16 grid max-w-4xl grid-cols-1 items-start gap-6 px-2 sm:grid-cols-[1.15fr_0.85fr] sm:gap-8 sm:px-4">
          <div className="overflow-hidden rounded-xl border border-[#89261F]/15 shadow-2xl transition-transform duration-300 hover:-translate-y-1 hover:scale-[1.02]">
            <img 
              referrerPolicy="no-referrer"
              src="https://i.postimg.cc/136Vqvkc/linhas-simulando-texto-(1).png" 
              alt="Certificado de Registro" 
              className="w-full h-auto object-contain"
            />
          </div>
          <div className="overflow-hidden rounded-xl border border-[#89261F]/15 shadow-2xl transition-transform duration-300 hover:-translate-y-1 hover:scale-[1.02] sm:mt-10">
            <img 
              referrerPolicy="no-referrer"
              src="https://i.postimg.cc/qvn631PG/linhas-simulando-texto-(2).png" 
              alt="Acompanhamento de Processo" 
              className="w-full h-auto object-contain"
            />
          </div>
        </div>

      </div>
    </section>
  );
}
