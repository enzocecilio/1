import { ArrowUpRight } from "lucide-react";
import { Translation } from "../types";

interface FinalCtaProps {
  t: Translation;
  onOpenDiagnostic: () => void;
}

export default function FinalCta({ t, onOpenDiagnostic }: FinalCtaProps) {
  return (
    <section className="bg-[#142841] px-4 pb-20 pt-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl rounded-3xl bg-gradient-to-br from-[#89261F] to-[#E4683F] p-[1px]">
        <div className="relative overflow-hidden rounded-[calc(1.5rem-1px)] bg-[#F1EAD9] px-6 py-14 text-center text-[#142841] sm:px-12 sm:py-20">
          <div className="absolute inset-x-0 top-0 h-2 bg-[linear-gradient(90deg,#89261F_0_28%,#E4683F_28%_52%,#142841_52%_58%,#89261F_58%_82%,#E4683F_82%)]" />
          <div className="section-eyebrow section-eyebrow--light mb-5">{t.final_cta_label}</div>
          <h2 className="font-display mx-auto max-w-4xl text-4xl uppercase leading-[0.95] tracking-wide sm:text-5xl lg:text-6xl">
            {t.final_cta_title}
          </h2>
          <p className="mx-auto mt-5 max-w-2xl text-sm leading-relaxed text-[#142841]/65 sm:text-base">
            {t.final_cta_body}
          </p>
          <button
            onClick={onOpenDiagnostic}
            className="site-lift-button site-lift-button--primary mt-8 inline-flex items-center gap-2 rounded-xl border border-[#142841] bg-[#142841] px-7 py-4 text-sm font-semibold text-white"
          >
            {t.final_cta_button}
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </section>
  );
}
